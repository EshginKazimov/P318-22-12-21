﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace Practise.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        public string Tags { get; set; }

        public int Rate { get; set; }

        [Required]
        public double Price { get; set; }

        public double DiscountPercent { get; set; }

        [Required]
        public double Tax { get; set; }

        [Required]
        public string Brand { get; set; }
        
        [Required]
        public string Code { get; set; }

        public bool IsDeleted { get; set; }

        public ICollection<ProductImage> ProductImages { get; set; }

        public ICollection<ProductCategory> ProductCategories { get; set; }

        [NotMapped] 
        public IFormFile[] Photos { get; set; }
    }
}
