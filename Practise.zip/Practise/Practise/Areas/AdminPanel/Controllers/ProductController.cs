﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Practise.Areas.AdminPanel.Data;
using Practise.DataAccessLayer;
using Practise.Models;
using Practise.ViewModels;

namespace Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class ProductController : Controller
    {
        private readonly AppDbContext _dbContext;

        public ProductController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _dbContext.Products.Where(x => x.IsDeleted == false)
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .ToListAsync();

            return View(products);
        }

        public async Task<IActionResult> Create()
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children)
                .ToListAsync();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = parentCategories[0].Children.ToList();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, int parentCategoryId, int? childCategoryId)
        {
            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children)
                .ToListAsync();
            ViewBag.ParentCategories = parentCategories;
            ViewBag.ChildCategories = parentCategories[0].Children.ToList();

            if (!ModelState.IsValid)
                return View();

            var isExist = await _dbContext.Products.AnyAsync(x => x.Title == product.Title);
            if (isExist)
            {
                ModelState.AddModelError("Title", "This product is already exist.");
                return View();
            }

            var existParent = parentCategories.Find(x => x.Id == parentCategoryId);
            if (existParent == null)
                return NotFound();

            if (childCategoryId != null)
            {
                var allChildren = parentCategories.SelectMany(x => x.Children).ToList();
                //if (!allChildren.Any(x => x.Id == childCategoryId))
                //{
                //    return NotFound();
                //}

                if (allChildren.All(x => x.Id != childCategoryId))
                {
                    return NotFound();
                }
            }

            if (product.Photos == null || product.Photos.Length == 0)
            {
                ModelState.AddModelError("Photos", "Please upload photo");
                return View();
            }

            var productImages = new List<ProductImage>();
            foreach (var photo in product.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("Photos", "Zehmet olmasa yalniz shekil sechin");
                    return View();
                }

                if (!photo.IsSizeAllowed(1))
                {
                    ModelState.AddModelError("Photos", "Zehmet olmasa 1 Mb-dan az olan shekil sechin");
                    return View();
                }

                var fileName = await FileUtil.GenerateFile(Constants.ImageFolderPath, photo);

                var productImage = new ProductImage
                {
                    Name = fileName,
                    Product = product
                };
                productImages.Add(productImage);
            }

            product.ProductImages = productImages;

            var productCategories = new List<ProductCategory>();

            var parentProductCategory = new ProductCategory
            {
                ProductId = product.Id,
                CategoryId = parentCategoryId
            };
            productCategories.Add(parentProductCategory);

            if (childCategoryId != null)
            {
                var childProductCategory = new ProductCategory
                {
                    ProductId = product.Id,
                    CategoryId = (int)childCategoryId
                };
                productCategories.Add(childProductCategory);
            }

            product.ProductCategories = productCategories;

            await _dbContext.Products.AddAsync(product);
            await _dbContext.SaveChangesAsync();

            return Content("Ok");
        }

        public async Task<IActionResult> LoadChildren(int? parentCategoryId)
        {
            if (parentCategoryId == null)
                return NotFound();

            var category = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain && x.Id == parentCategoryId)
                .Include(x => x.Children).FirstOrDefaultAsync();

            return PartialView("_ProductChildrenPartial", category.Children.ToList());
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();

            var product = await _dbContext.Products
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (product == null)
                return NotFound();

            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children)
                .ToListAsync();

            var productViewModel = new ProductViewModel
            {
                Id = product.Id,
                Title = product.Title,
                Description = product.Description,
                IsDeleted = product.IsDeleted,
                ProductImages = product.ProductImages.ToList(),
                Rate = product.Rate,
                Brand = product.Brand,
                Code = product.Code,
                DiscountPercent = product.DiscountPercent,
                Price = product.Price,
                Tags = product.Tags,
                Tax = product.Tax,
                ParentCategories = parentCategories,
                SelectedParentCategoryId = product.ProductCategories
                    .FirstOrDefault(x => x.Category.IsDeleted == false && x.Category.IsMain).CategoryId,
                SelectedChildCategoryId = product.ProductCategories
                    .FirstOrDefault(x => x.Category.IsDeleted == false && x.Category.IsMain == false).CategoryId,
            };

            productViewModel.ChildCategories = parentCategories
                .FirstOrDefault(x => x.Id == productViewModel.SelectedParentCategoryId).Children.ToList();

            return View(productViewModel);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id, ProductViewModel productViewModel)
        {
            if (id == null)
                return NotFound();

            if (id != productViewModel.Id)
                return BadRequest();

            var existProduct = await _dbContext.Products
                .Where(x => x.IsDeleted == false && x.Id == id)
                .Include(x => x.ProductImages)
                .Include(x => x.ProductCategories).ThenInclude(x => x.Category)
                .FirstOrDefaultAsync();
            if (existProduct == null)
                return NotFound();

            var parentCategories = await _dbContext.Categories
                .Where(x => x.IsDeleted == false && x.IsMain)
                .Include(x => x.Children)
                .ToListAsync();
            productViewModel.ParentCategories = parentCategories;
            productViewModel.ChildCategories = parentCategories
                .FirstOrDefault(x => x.Id == productViewModel.SelectedParentCategoryId).Children.ToList();
            productViewModel.ProductImages = existProduct.ProductImages.ToList();

            if (!ModelState.IsValid)
            {
                return View(productViewModel);
            }

            var isExistProductWithSameName = await _dbContext.Products
                .AnyAsync(x => x.IsDeleted == false && x.Title == productViewModel.Title
                                                    && x.Id != id);
            if (isExistProductWithSameName)
            {
                ModelState.AddModelError("Title", "This product is already exist.");
                return View(productViewModel);
            }

            if (productViewModel.SelectedParentCategoryId == 0)
                return NotFound();

            if (!parentCategories.Any(x => x.Id == productViewModel.SelectedParentCategoryId))
                return NotFound();

            if (productViewModel.SelectedChildCategoryId == 0)
                return NotFound();

            if (parentCategories.SelectMany(x => x.Children).All(x => x.Id != productViewModel.SelectedChildCategoryId))
                return NotFound();

            if (productViewModel.Photos != null && productViewModel.Photos.Length > 0)
            {
                foreach (var photo in productViewModel.Photos)
                {
                    if (!photo.IsImage())
                    {
                        ModelState.AddModelError("Photos", "Zehmet olmasa yalniz shekil sechin");
                        return View();
                    }

                    if (!photo.IsSizeAllowed(1))
                    {
                        ModelState.AddModelError("Photos", "Zehmet olmasa 1 Mb-dan az olan shekil sechin");
                        return View();
                    }

                    var fileName = await FileUtil.GenerateFile(Constants.ImageFolderPath, photo);

                    var productImage = new ProductImage
                    {
                        Name = fileName,
                        ProductId = (int)id
                    };
                    await _dbContext.ProductImages.AddAsync(productImage);
                    await _dbContext.SaveChangesAsync();
                }
            }

            existProduct.ProductCategories.FirstOrDefault(x => x.Category.IsMain && x.Category.IsDeleted == false)
                .CategoryId = productViewModel.SelectedParentCategoryId;
            existProduct.ProductCategories.FirstOrDefault(x => x.Category.IsMain == false && x.Category.IsDeleted == false)
                .CategoryId = (int)productViewModel.SelectedChildCategoryId;

            existProduct.Title = productViewModel.Title;
            existProduct.Description = productViewModel.Description;
            existProduct.Rate = productViewModel.Rate;
            existProduct.Brand = productViewModel.Brand;
            existProduct.Code = productViewModel.Code;
            existProduct.DiscountPercent = productViewModel.DiscountPercent;
            existProduct.Price = productViewModel.Price;
            existProduct.Tags = productViewModel.Tags;
            existProduct.Tax = productViewModel.Tax;

            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteImage(int? id)
        {
            if (id == null)
                return NotFound();

            var productImage = await _dbContext.ProductImages.FindAsync(id);
            if (productImage == null)
                return NotFound();

            var path = Path.Combine(Constants.ImageFolderPath, productImage.Name);
            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }

            _dbContext.ProductImages.Remove(productImage);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Update), new {Id = productImage.ProductId});
        }
    }
}
