﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Practise.Models;

namespace Practise.ViewModels
{
    public class HomeViewModel
    {
        public List<Category> Categories { get; set; }
    }
}
