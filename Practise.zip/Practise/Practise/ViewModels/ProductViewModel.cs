﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Practise.Models;

namespace Practise.ViewModels
{
    public class ProductViewModel
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Title { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        public string Tags { get; set; }

        public int Rate { get; set; }

        [Required]
        public double Price { get; set; }

        public double DiscountPercent { get; set; }

        [Required]
        public double Tax { get; set; }

        [Required]
        public string Brand { get; set; }

        [Required]
        public string Code { get; set; }

        public bool IsDeleted { get; set; }

        public List<ProductImage> ProductImages { get; set; }

        public List<Category> ParentCategories { get; set; }

        public int SelectedParentCategoryId { get; set; }

        public List<Category> ChildCategories { get; set; }

        public int? SelectedChildCategoryId { get; set; }

        public IFormFile[] Photos { get; set; }
    }
}
